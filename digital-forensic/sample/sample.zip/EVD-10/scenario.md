# EVD-10 — Laptop Sindikat Investasi Kripto Bodong

**Perkara:** Operasi KABUT GELAP (fiktif). Klaster pencucian uang dan investasi bodong "Cahaya X Trade".
**Barang bukti:** laptop **CAD-DIRUT01** milik **Hartono Wijaya** ("Pak H"), Direktur Utama **PT Cahaya Aset Digital**. Disita saat penggeledahan kantor Ruko Graha Niaga Blok C-7, Semarang, pada 15 Juli 2025 pukul 06.30 WIB.
**Image:** `EVD-10.dd` (raw, 90 MiB, MBR + NTFS). Zona waktu WIB.

## Latar belakang
PT Cahaya Aset Digital mengoperasikan platform "Cahaya X Trade" (`cahayax-trade.com`) yang menjanjikan profit 3–10% per hari. Tim CS (termasuk Andika/"Rina", EVD-07) membujuk korban. Wallet penampung TRC20 `TJfRCJ…` muncul di EVD-01, EVD-06, dan EVD-07.

Pada malam 14 Juli 2025, sehari sebelum penggeledahan, Hartono diduga sudah mendapat bocoran dan **menghapus banyak file** serta mengosongkan Recycle Bin.

## Yang diminta penyidik
1. Identifikasi materi penipuan: platform palsu, broadcast, naskah CS, dan dokumen perusahaan.
2. Pulihkan spreadsheet korban, setoran, dan pool USDT.
3. Rekonstruksi aliran dana dari BEC, penjualan data, penipuan, dan tebusan ransomware.
4. Hubungkan Hartono dengan Bagus (EVD-05), Yoga (EVD-06), Andika (EVD-07), Fajar (EVD-08), dan Rendi (EVD-01).
