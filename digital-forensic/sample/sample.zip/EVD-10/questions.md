# EVD-10 — Soal Latihan (Laptop Sindikat Investasi Kripto)

Persiapan: `EVD-10.dd`, time zone Asia/Jakarta. Ingest: **Recent Activity, Hash Lookup, Keyword Search (regex wallet/rekening), EXIF Parser, Embedded File Extractor, File Type Identification, Interesting Files**. Disarankan memakai Central Repository bersama EVD-05/06/07.

## A. Dasar (10 soal)
1. **[mmls / OS info]** Sebutkan tabel partisi, sektor awal NTFS, nama komputer, dan organisasi terdaftar.
2. **[Directory tree]** Sebutkan dokumen di `Documents/Perusahaan`. Siapa Direktur Utama menurut akta?
3. **[Metadata]** Pada dokumen kantor di `Documents/Perusahaan`, siapa *Author* dan siapa *Last Modified By*?
4. **[Images]** Apa yang ditunjukkan `ss_platform_03.png`, dan mengapa gambar ini penting?
5. **[Text]** Apa isi `Broadcast_WA_Mei_2025.txt`?
6. **[Deleted Files]** Berapa file berstatus terhapus? Kelompokkan berdasarkan folder.
7. **[Web History]** Apa yang dicari Hartono pada 14 Juli pukul 22:00 dan 22:02?
8. **[Web Accounts]** Akun apa saja yang tersimpan di Chrome Login Data?
9. **[EXIF / Geolocation]** Di mana lokasi foto di `Pictures/Kantor`?
10. **[Email]** Email apa saja yang ada di `Documents/Email` (aktif dan terhapus)?

## B. Menengah (10 soal)
11. **[Deleted Files + Spreadsheet]** Pulihkan `Rekap_Member_Deposit_2025.xlsx`. Berapa jumlah member dan total depositnya? Apakah ketiga korban EVD-07 tercantum?
12. **[Deleted Files + Spreadsheet]** Pulihkan `Rekap_Pool_USDT.xlsx`. Sebutkan semua sumber dana masuk dan nominalnya.
13. **[Deleted Files]** Pulihkan `Cuci_tebusan_SLN_0521.txt`. Bagaimana tebusan SLN dicuci?
14. **[Recycle Bin terhapus]** Recycle Bin sudah dikosongkan. Temukan pasangan `$I`/`$R` yang terhapus, baca path asli dan waktu penghapusan dari `$I`, lalu sebutkan isinya.
15. **[Hash / Central Repository]** File mana di laptop ini yang identik dengan file di EVD-05 dan EVD-07? Sebutkan MD5-nya.
16. **[Web History]** Pada 2 Mei 2025 pukul 21:12, apa yang dilihat Hartono di Dropbox? Cocokkan dengan `sync_history.db` di EVD-05.
17. **[Keyword Search regex TRON/BTC]** Wallet apa saja yang muncul, dan di file mana?
18. **[Recent Documents]** `.lnk` mana yang menunjuk ke file yang sekarang sudah dihapus? Apa nilai buktinya?
19. **[Keyword Search: rekening]** Rekening apa yang dipakai menerima dana "konsultan palsu" hasil pencucian?
20. **[Timeline]** Susun urutan penghapusan pada 14 Juli malam, dari pencarian Google sampai file terakhir dihapus.

## C. Sulit (5 soal)
21. **[Analisis keuangan]** Dari pool USDT, hitung total masuk dan keluar serta kelompokkan per kejahatan asal (BEC, jual data, penipuan investasi, tebusan). Sebutkan juga pembayaran ke r3ndyx, f4j4r, dan "orang dalam".
22. **[Korelasi]** Petakan peran setiap orang berdasarkan artefak EVD-10 (kontak_tim, pembagian_SLN, Struktur_Organisasi, pool), lalu cocokkan dengan EVD-01, 05, 06, 07, dan 08.
23. **[Analisis anti-forensik]** Apa saja yang dilakukan Hartono untuk menghapus jejak, dan mengapa semuanya masih dapat dipulihkan? Apa yang akan membuat file benar-benar tidak terpulihkan?
24. **[Analisis metadata]** "Last Modified By: Andika" di dokumen Perusahaan dan Rekap Member. Apa artinya? Apakah ini membuktikan Andika mengakses laptop ini?
25. **[Analisis hukum-teknis]** Bukti apa di EVD-10 yang mendukung unsur pencucian uang (menempatkan, mentransfer, menyamarkan)? Apa keterbatasan bukti digital ini tanpa data bank atau exchange?

## D. Kesimpulan untuk Jaksa
Tulis kesimpulan singkat: peran Hartono, aliran dana yang terdokumentasi, file yang dihapus menjelang penggeledahan dan hasil pemulihannya, apa yang tidak terbukti (penerimaan dana riil, identitas kabut_admin), dan keterbatasannya (spreadsheet buatan pelaku dapat tidak akurat, dokumen palsu, Recycle Bin rekonstruksi).
