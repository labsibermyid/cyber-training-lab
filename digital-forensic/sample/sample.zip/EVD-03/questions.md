# EVD-03 — Soal Latihan (Workstation Ransomware)

Persiapan: `EVD-03.dd`, time zone Asia/Jakarta. Ingest: **Recent Activity, File Type Identification, Extension Mismatch Detector, Hash Lookup (KABUT_known_bad), Email Parser, Embedded File Extractor, Keyword Search, Encryption Detection, PhotoRec Carver, Interesting Files**.

## A. Dasar (10 soal)
1. **[mmls / Data Sources]** Sebutkan tipe tabel partisi, tipe partisi, dan sektor awal volume NTFS.
2. **[Keyword/File Search: *.kabut]** Berapa file berekstensi `.kabut`? Di folder mana saja file tersebut berada?
3. **[Directory tree]** Berapa salinan `BACA_SAYA_KABUT.txt`? Apakah isinya identik (MD5)?
4. **[Text viewer]** Dari catatan tebusan, sebutkan ID korban, alamat email, wallet BTC, nominal tebusan, dan alamat situs kebocoran.
5. **[Email Messages]** Siapa pengirim email pemicu, kapan diterima, dan apa nama lampirannya?
6. **[Web Downloads]** Kapan ZIP lampiran diunduh dan ke mana disimpan?
7. **[Directory tree / Text]** Apa isi `ProgramData/KabutGelap/svc/config.json`?
8. **[Text]** Menurut `Desktop/negosiasi_kabut.txt`, berapa tawaran awal, tawaran Arunika, dan penawaran akhir pelaku?
9. **[Metadata]** Siapa *Author* dan *Last Modified By* `Documents/Nego/Tawaran_ke_peretas.docx`?
10. **[Web History / Web Search]** Apa saja yang dicari Sri di Google pada pagi 3 Juni?

## B. Menengah (10 soal)
11. **[Extension Mismatch Detector]** File apa yang ekstensinya tidak sesuai dengan signature-nya? Tunjukkan magic bytes-nya di Hex viewer.
12. **[Hash Lookup / MD5]** Buktikan bahwa `foto_produk_katalog.jpg` dan `AppData/Local/Temp/WinUpdate.exe` adalah file yang sama.
13. **[Analisis .lnk]** Apa target dan argumen `Katalog_Permintaan_Hotel.pdf.lnk`? Bagaimana cara kerja penyamaran ini, dan apakah sampelnya berbahaya?
14. **[File Metadata / istat]** Bandingkan `$STANDARD_INFORMATION` dan `$FILE_NAME` milik `WinUpdate.exe`. Apa kesimpulan Anda?
15. **[Hex viewer]** Baca *TimeDateStamp* header PE `WinUpdate.exe` (offset 0x88). Kapan itu, dan bagaimana nilai ini memperkuat jawaban soal 14?
16. **[Deleted Files]** Temukan file `.bat` yang dihapus. Apa isinya dan apa tujuannya?
17. **[$OrphanFiles]** File apa saja yang muncul di `$OrphanFiles`? Mengapa file-file itu tidak punya path induk, dan dari folder mana asalnya (lihat log)?
18. **[Text]** Menurut `exfil_list.txt` dan `kbl.log`, data apa yang dicuri, ke IP mana, dan kapan?
19. **[Hash Lookup]** File mana yang ditandai *Notable* oleh hash set KABUT_known_bad?
20. **[Analisis]** Folder `Pictures/Acara_Kantor` dan `Documents/Arsip_2024` tidak terenkripsi. Artefak mana yang menjelaskan alasannya?

## C. Sulit (5 soal)
21. **[PhotoRec Carver / $CarvedFiles]** Berapa file asli (sebelum dienkripsi) yang dapat dipulihkan utuh lewat carving? Sebutkan minimal lima, termasuk `Daftar_Gaji_Mei_2025.xlsx`, dan cara membuktikan file hasil carving sama dengan aslinya.
22. **[Analisis struktur]** Jelaskan mengapa sebagian besar file asli tidak muncul sebagai entri terhapus bernama di Autopsy, dan mengapa sebagian lain sama sekali tidak dapat dipulihkan.
23. **[Prefetch / Timeline]** Rekonstruksi rantai eksekusi dari 2 Juni 14:12 sampai 3 Juni 01:53 (minimal 10 langkah) dengan sumber artefak masing-masing, termasuk bukti penghapusan shadow copy.
24. **[Korelasi]** Bandingkan wallet, email kontak, IP, dan string locker dengan EVD-08 dan EVD-11. Apa yang sama dan apa yang berbeda? Apa artinya bagi atribusi kelompok?
25. **[Analisis]** Pelaku menulis "pernah 'membantu' perusahaan logistik di Semarang bulan lalu". Apakah ini bukti yang cukup bahwa pelaku yang sama menyerang SLN? Jelaskan.

## D. Kesimpulan untuk Jaksa
Tulis kesimpulan singkat: vektor infeksi, kerugian (file terenkripsi, data dicuri), upaya anti-forensik yang terbukti, apa yang tidak terbukti (misalnya identitas operator, pembayaran tebusan), dan keterbatasannya (prefetch format rekonstruksi, data tercarve tanpa metadata, klaim pelaku di chat).
