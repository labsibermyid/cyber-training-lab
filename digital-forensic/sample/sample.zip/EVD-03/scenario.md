# EVD-03 — Workstation Terkena Ransomware

**Perkara:** Operasi KABUT GELAP (fiktif). Laporan korban kedua: PT Arunika Mebel Jepara.
**Barang bukti:** PC admin keuangan **ARUNIKA-ADM01**, pengguna **Sri Wahyuni**. Disita pada 5 Juni 2025 pukul 17.00 WIB.
**Image:** `EVD-03.dd` (raw, 82 MiB, MBR + NTFS). Zona waktu WIB.

## Latar belakang
Pada pagi 3 Juni 2025 Sri mendapati semua file kerjanya berekstensi `.kabut` dan ada catatan `BACA_SAYA_KABUT.txt`. Pelaku meminta 0,85 BTC. Direktur (Budi Santoso) memerintahkan Sri bernegosiasi lewat email, lalu memutuskan melapor ke polisi tanpa membayar.

Sehari sebelumnya Sri menerima email "permintaan penawaran mebel restoran" dari "Hotel Nusa Indah" berlampiran ZIP katalog.

## Yang diminta penyidik
1. Tentukan vektor awal infeksi dan file pemicunya.
2. Identifikasi dropper, locker, konfigurasi, wallet, dan kontak pelaku.
3. Buktikan upaya anti-forensik: penghapusan shadow copy, timestomp, dan pembersihan folder kerja.
4. Pulihkan sebanyak mungkin file asli sebelum dienkripsi.
5. Cari indikasi pencurian data (double extortion) dan kaitannya dengan korban lain (SLN).
