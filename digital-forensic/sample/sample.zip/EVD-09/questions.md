# EVD-09 — Soal Latihan (PC Bersama, Atribusi)

Persiapan: `EVD-09.dd`, time zone Asia/Jakarta. Ingest: **Recent Activity, EXIF Parser, Hash Lookup, Keyword Search, File Type Identification, Interesting Files**. Gunakan **Timeline** dengan filter 2025-04-15 16:15–16:50.

## A. Dasar (10 soal)
1. **[mmls / OS]** Sebutkan tabel partisi, sektor awal NTFS, dan nama komputer.
2. **[OS Accounts]** Akun pengguna apa saja yang ada? Sebutkan SID masing-masing.
3. **[Text]** Menurut `logon_audit.log`, siapa saja yang login pada 15 April 2025 beserta jam login dan logoff-nya?
4. **[Web History]** Dari profil mana halaman `…/pay/PAY-2025-0415-007/approve` diakses, dan pukul berapa?
5. **[Web Accounts / Login Data]** Di profil mana saja tersimpan kredensial e-Approval dengan username `hendra.wibisono`?
6. **[USB Device Attached]** Perangkat USB apa yang terhubung pada 15 April? Sebutkan serial dan waktunya.
7. **[Directory tree]** Apa isi folder `ProgramData/Intel/Graphics`?
8. **[Registry SOFTWARE: Run]** Program apa yang dijalankan otomatis saat startup?
9. **[Document]** Apa isi `Form_Cuti_14-18_April_2025.pdf` milik Hendra?
10. **[Text]** Apa yang ditulis Lina di `catatan_magang.txt`?

## B. Menengah (10 soal)
11. **[EXIF / Geolocation]** Foto mana di `Pictures/Cuti_Bali` yang diambil paling dekat dengan waktu approval? Sebutkan koordinat dan waktunya. Perhatikan offset zona waktu: berapa waktunya dalam WIB?
12. **[File Metadata]** Kapan foto-foto Bali dibuat di PC ini (created NTFS)? Mengapa berbeda dengan waktu EXIF, dan apa artinya?
13. **[Recent Documents / .lnk]** Di profil Hendra ada `.lnk` ke drive E:. Sebutkan VSN, label, dan waktunya. Volume ini milik siapa (lihat juga profil Bagus)?
14. **[.lnk + Prefetch]** Bagaimana keylogger dipasang? Sebutkan path installer, waktunya, akun yang menjalankan, dan bukti pendukungnya.
15. **[File Metadata / istat]** Bandingkan `$SI` dan `$FN` milik `igfxhlp.exe`. Apa kesimpulannya?
16. **[Ekstraksi + decode base64]** Dekode `klg_20250411.dat`. Apa yang terekam, dan siapa yang mengetik kata sandi Hendra pada 11 April?
17. **[Deleted Files]** Pulihkan dan dekode `klg_20250415.dat`. Apa yang terekam pada 15 April 16:31–16:46? Kapan file ini dihapus (lihat log dan isinya)?
18. **[Web History – Bagus]** Apa yang dicari dan dibuka Bagus pada 8, 9, 10, dan 15 April?
19. **[Analisis red herring]** Tunjukkan bukti yang mengarah ke Lina, lalu jelaskan mengapa bukti itu tidak cukup.
20. **[Timeline]** Buat timeline 15 April 16:15–16:56 dari minimal enam sumber artefak berbeda.

## C. Sulit (5 soal)
21. **[Analisis bertentangan]** Buat tabel: untuk Hendra, Lina, Bagus, dan Dewi, artefak yang **memberatkan** dan yang **meringankan**.
22. **[Analisis]** Keylogger mencatat `[hendra.wibisono][Windows Logon] Hw#Fin2025` pada 16:31:05. Apa yang dapat dan tidak dapat disimpulkan dari baris ini tentang siapa yang mengetik?
23. **[Korelasi EVD-05]** Flashdisk DATA_BG (serial 070B2C11D3A4E519) juga tercatat di laptop Bagus (EVD-05). Apa nilai bukti korelasi ini?
24. **[Analisis]** Isi `E:\catatan_PAY0415.txt` tidak ada di image. Bagaimana Anda menyikapi bukti yang hanya diketahui keberadaannya (nama, ukuran) tetapi tidak isinya?
25. **[Kesimpulan atribusi]** Siapa yang paling mungkin memakai akun Hendra pada 15 April 16:31–16:47? Nyatakan tingkat keyakinan (misalnya kuat/sedang/lemah) dan bukti tambahan apa yang diperlukan agar kesimpulan itu kuat di persidangan.

## D. Kesimpulan untuk Jaksa
Tulis kesimpulan singkat: apa yang terbukti tentang penggunaan akun Hendra, apa yang tidak terbukti (identitas orang secara fisik), alternatif penjelasan yang telah disingkirkan atau belum, dan keterbatasan (tidak ada EVTX/CCTV, log agen pihak ketiga, EXIF dapat diubah, password akun dibagikan).
