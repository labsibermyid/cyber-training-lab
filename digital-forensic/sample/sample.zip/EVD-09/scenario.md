# EVD-09 — PC Kantor Bersama (Atribusi Pengguna)

**Perkara:** Operasi KABUT GELAP (fiktif). Klaster BEC PT Samudra Logistik Nusantara.
**Barang bukti:** PC bersama divisi keuangan **SLN-FIN-PC03** (10.20.3.23), dipakai bergantian oleh beberapa pegawai. Dicabut dari jaringan dan diserahkan pada 22 April 2025.
**Image:** `EVD-09.dd` (raw, 90 MiB, GPT + NTFS). Zona waktu WIB.

## Latar belakang
Pembayaran BEC Rp 1,475 M (EVD-02) disetujui di sistem e-Approval atas nama **hendra.wibisono** pada **15 April 2025 pukul 16:40:52** dari terminal SLN-FIN-PC03. Hendra menyatakan sedang cuti di Bali (14–18 April) dan tidak pernah menyetujuinya. PC ini juga dipakai Dewi (staf), Lina (mahasiswa magang), dan Bagus (IT, melakukan "maintenance" pada 10 April).

**Pertanyaan utama:** siapa yang sebenarnya duduk di depan PC dan memakai akun Hendra pada 15 April 16:31–16:47?

## Yang diminta penyidik
Kumpulkan dan timbang bukti yang **saling bertentangan**: aktivitas profil Hendra, kredensial Hendra yang tersimpan di browser orang lain, keylogger, perangkat USB, dan alibi berbasis foto. Sampaikan kesimpulan atribusi beserta tingkat keyakinan dan keterbatasannya.
