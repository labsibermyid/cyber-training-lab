# EVD-06 — Laptop Penjual Data

**Perkara:** Operasi KABUT GELAP (fiktif)
**Barang bukti:** laptop pribadi **YOGA-PC** (Windows 10 Home) milik **Yoga Pratama**, yang diduga beralias **datakingid** di forum `pasarbocor.cc`. Disita dari rumah kontrakan di Surabaya pada 1 Juli 2025 pukul 06.00 WIB.
**Image:** `EVD-06.dd` (raw, 80 MiB, **NTFS tanpa tabel partisi**, hasil akuisisi logical volume C:). Zona waktu WIB.

## Latar belakang
Patroli siber menemukan thread "[JUAL] DB pelanggan perusahaan logistik Semarang 2025 + VPN" oleh datakingid pada 10 Mei 2025. Sampel data cocok dengan data pelanggan PT Samudra Logistik Nusantara. Penyidik menduga Yoga hanyalah "penjual". Data berasal dari orang dalam (EVD-05), dan sebagian hasil penjualan disetor ke sindikat (EVD-10).

## Yang diminta penyidik
1. Data apa saja yang diperjualbelikan, dan dari mana asalnya?
2. Siapa pihak yang terlibat (penyedia data, pembeli, penerima setoran)?
3. Alur uang kripto: wallet, nominal, dan konversi ke rupiah.
4. Apa yang disembunyikan atau dihapus oleh tersangka?
