# EVD-06 — Soal Latihan (Laptop Penjual Data)

Persiapan: `EVD-06.dd`, time zone Asia/Jakarta. Ingest: **Recent Activity, Keyword Search (tambahkan daftar regex sendiri), Hash Lookup, File Type Identification, Embedded File Extractor, EXIF Parser, Interesting Files**. Bila tersedia, aktifkan **Central Repository** dan tambahkan EVD-04/EVD-05 ke case yang sama.

Daftar regex yang disarankan untuk dibuat:
- BTC bech32: `\bbc1[ac-hj-np-z02-9]{11,71}\b`
- TRON: `\bT[1-9A-HJ-NP-Za-km-z]{33}\b`
- NIK: `\b33\d{14}\b`

## A. Dasar (10 soal)
1. **[Data Sources]** Apakah image ini punya tabel partisi? File system apa yang dipakai, dan apa nama komputernya?
2. **[Directory tree]** Sebutkan subfolder di `Documents/dagangan` dan jenis data di masing-masing.
3. **[Text]** Menurut `README_jual.txt`, apa saja yang dijual dari data SLN dan berapa harganya?
4. **[Web History – Firefox]** Kapan thread penjualan dibuat, dan apa URL thread-nya?
5. **[Directory tree]** Di mana ekspor chat Telegram berada? Dengan siapa percakapan itu?
6. **[Text]** Apa isi `Documents/wallet/alamat.txt`?
7. **[Text/CSV]** Dari `riwayat_transaksi_tukarkripto.csv`, berapa rupiah yang ditarik dan ke rekening mana?
8. **[EXIF]** Ponsel apa yang dipakai untuk foto di `Pictures/HP`, dan di kota mana sebagian besar foto diambil?
9. **[Deleted Files]** Sebutkan file berstatus terhapus.
10. **[Web Downloads – Firefox]** File apa saja yang diunduh, dari mana, dan kapan?

## B. Menengah (10 soal)
11. **[Keyword Search regex BTC/TRON]** Sebutkan semua alamat wallet yang ditemukan dan peran masing-masing (escrow, pribadi, pool).
12. **[Keyword Search: domain SLN]** Akun karyawan SLN mana yang ada di combolist? Dari mana kemungkinan asalnya (bandingkan dengan EVD-01)?
13. **[Hash / Central Repository]** Hitung MD5 `data_pelanggan_SLN_2025.csv` dan `Downloads/SLN_arsip_0502.7z`. Di barang bukti lain mana file dengan hash yang sama ditemukan?
14. **[Hash]** `KSP_kudus/ksp_cms_anggota.sql` identik dengan file mana di EVD-04? Apa artinya?
15. **[Text HTML]** Dalam `pm_cahaya_ops.html`, berapa pembagian hasilnya dan ke wallet mana setoran dikirim?
16. **[Chat Telegram]** Sebutkan kronologi percakapan dengan "Pak H (Cahaya)". Pesan mana yang menunjukkan setoran sudah dikirim, dan kapan?
17. **[Images]** Apa isi `bukti_tx_1.png`? Cocokkan nominal dan waktunya dengan CSV dan chat.
18. **[Deleted Files]** Pulihkan `pm_buyer_jkt.html`. Informasi apa yang ada di dalamnya?
19. **[Deleted Files / Hex]** Apa yang terlihat ketika Anda membuka `Desktop/seed_phrase_backup.txt` di Autopsy? Jelaskan fenomenanya.
20. **[Web History]** Apa yang dicari Yoga pada 12 Mei pukul 21.50 dan 18 Mei pukul 23.00? Kaitkan dengan soal 19 dan 21.

## C. Sulit (5 soal)
21. **[Hex viewer / Steganografi]** Salah satu gambar di `Pictures/meme` berukuran janggal. Temukan gambar itu, tunjukkan offset penanda akhir JPEG (`FF D9`) dan awal data tersembunyi, ekstrak datanya, lalu sebutkan isinya.
22. **[Analisis]** Isi data tersembunyi itu sama dengan file yang di-wipe di soal 19. Apa nilai pembuktiannya, dan apa artinya bagi penilaian niat menyembunyikan?
23. **[Alur dana]** Rekonstruksi alur dana 11–12 Mei 2025: dari pembeli, ke escrow BTC, konversi, setoran ke pool, sampai penarikan rupiah. Sertakan nominal dan sumber artefak di tiap langkah.
24. **[Korelasi]** Siapa "cahaya_ops" / "Pak H"? Kaitkan wallet pool `TJfRCJ…` dengan EVD-01, EVD-07, dan EVD-10.
25. **[Analisis atribusi]** Buktikan bahwa pengguna laptop ini adalah "datakingid" dengan minimal empat artefak, lalu nilai kekuatannya.

## D. Kesimpulan untuk Jaksa
Tulis kesimpulan singkat: perbuatan memperjualbelikan data pribadi yang terbukti (data apa, kapan, harga, pembeli), alur dana, hubungan dengan sindikat, apa yang tidak terbukti (identitas pembeli "buyer_jkt", identitas Pak H hanya dari nama tampilan), dan keterbatasannya (wallet/explorer fiktif dan perlu konfirmasi exchange, file di-wipe).
