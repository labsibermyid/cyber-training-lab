# EVD-01 — Flashdisk Pelaku Phishing

**Perkara:** Operasi KABUT GELAP — LP/B/117/IV/2025/SIBER/PDNR (fiktif)
**Barang bukti:** 1 (satu) flashdisk SanDisk Cruzer Blade 64 GB, label tulisan tangan "R", disita dari kamar kos tersangka **Rendi Saputra** (alias *r3ndyx*) di Semarang pada 24 April 2025 pukul 07.10 WIB.
**Image:** `EVD-01.dd` (raw, 64 MiB; replika diperkecil untuk pelatihan)
**Zona waktu:** WIB (UTC+7). FAT menyimpan waktu lokal, jadi **atur time zone data source ke Asia/Jakarta (GMT+7)** saat *Add Data Source*.

## Latar belakang
Pada 8 April 2025 sejumlah karyawan PT Samudra Logistik Nusantara (SLN, `samlognus.co.id`) menerima email "[PENTING] Pembaruan Kata Sandi Email Kantor" yang mengarah ke halaman login palsu di `mail.samlognus-webmail.com` (IP 198.51.100.23). Seminggu kemudian staf keuangan SLN, Dewi Anggraini, menjadi korban *Business Email Compromise* (lihat EVD-02).

Penyidik menduga Rendi membuat dan mengoperasikan kit phishing tersebut, lalu menyerahkan kredensial hasil panen kepada pihak bernama **kabut_admin**. Di BAP, Rendi menyatakan flashdisk itu "hanya berisi tugas kuliah dan pekerjaan freelance".

## Yang diminta penyidik
1. Pastikan apakah flashdisk berisi kit phishing, template email, daftar target, dan hasil panen kredensial.
2. Pulihkan file yang dihapus tersangka.
3. Hubungkan isi flashdisk dengan tersangka (atribusi) dan dengan pihak lain (kabut_admin).
4. Identifikasi karakteristik volume yang bisa dicocokkan dengan jejak USB di perangkat korban (EVD-02).
