# EVD-01 — Soal Latihan (Flashdisk Pelaku Phishing)

Sebelum mulai: buat case baru, *Add Data Source → Disk Image or VM File → EVD-01.dd*, time zone **Asia/Jakarta (GMT+7)**. Jalankan ingest module: **File Type Identification, Extension Mismatch Detector, Hash Lookup, EXIF Parser, Embedded File Extractor, Keyword Search, Email Parser, PhotoRec Carver**. Hash set `hashsets/KABUT_known_bad.txt` diimpor sebagai *Notable* (Tools → Options → Hash Sets).

Kolom **[Modul]** menunjukkan menu atau modul Autopsy yang dipakai.

## A. Dasar (10 soal)
1. **[Data Sources tree / mmls]** Apa jenis tabel partisi image ini? Di sektor berapa partisi FAT32 dimulai, dan berapa panjangnya (sektor)?
2. **[File System Details pada volume]** Sebutkan *volume label* dan *Volume Serial Number* file system tersebut.
3. **[Views → Deleted Files → File System]** Berapa **file** (bukan folder) berstatus terhapus pada volume ini? Sebutkan juga berapa folder yang terhapus.
4. **[Directory tree]** Di folder mana kit phishing disimpan? Sebutkan file yang berisi konfigurasi alamat email penerima hasil panen beserta alamat email tersebut.
5. **[Content Viewer → Text]** Berdasarkan `config.php`, apa domain phishing dan IP server yang digunakan?
6. **[Directory tree / Text]** Berapa alamat email target yang tercantum di `target/emails_sln.txt`? Divisi apa yang disebut sebagai "target utama" di `catatan_target.txt`?
7. **[Email Parser / Communications]** Apa subjek dan alamat pengirim pada template email `.eml`? Ke URL mana tautannya mengarah?
8. **[File Metadata / Application → Metadata]** Siapa *Author* dan *Last Modified By* pada `pribadi/CV_Rendi_Saputra.docx`? Kapan dokumen itu dibuat (internal)?
9. **[Metadata]** Siapa *Author* pada `template_email/invoice_template_vendor.docx`? Kenapa nilai ini penting bagi atribusi?
10. **[EXIF Parser → Results → EXIF Metadata]** Apa merek dan model kamera pada `pribadi/KTP_scan.jpg`, dan kapan foto diambil?

## B. Menengah (10 soal)
11. **[Deleted Files + Content Viewer]** Pulihkan file log hasil panen tanggal 8 April 2025. Ada berapa kredensial di dalamnya? Akun karyawan divisi keuangan mana yang tercatat, pukul berapa, dan apa kata sandinya? Sebutkan nama file sebagaimana ditampilkan Autopsy, inode (alamat entri direktori), dan MD5-nya.
12. **[Extension Mismatch Detector]** File mana yang ekstensinya tidak cocok dengan isinya? Apa tipe sebenarnya (MIME), dan apa isi file itu? Akun mana yang berstatus "VPN OK"?
13. **[Keyword Search → substring "samlognus"]** Sebutkan semua varian domain yang mengandung kata `samlognus` dan bedakan mana domain asli SLN dan mana domain palsu.
14. **[Keyword Search → regex Email Addresses]** Alamat email pribadi operator apa yang muncul di kit maupun di CV? Sebutkan minimal dua file tempatnya muncul.
15. **[Hash Lookup → Hashset Hits]** Setelah hash set known-bad diimpor, file apa saja yang cocok (*Notable*)?
16. **[File Search by attributes → MD5 / Duplicate]** Temukan dua file screenshot yang identik (MD5 sama). Sebutkan path keduanya dan MD5-nya.
17. **[Geolocation / EXIF]** Foto `pribadi/foto_hp/IMG_20250407_101233.jpg` diambil di koordinat berapa dan pukul berapa? Lokasi itu dekat dengan alamat siapa (lihat scenario/world)?
18. **[File Metadata]** Bisakah waktu penghapusan `log_0408.txt` ditentukan dari file system FAT32? Jelaskan stempel waktu apa yang tersedia di entri direktori FAT.
19. **[Deleted Files]** Folder apa yang terhapus di bawah `kit/` dan apa isinya? Apakah relevan dengan perkara?
20. **[Text viewer]** Menurut `hasil/kirim_ke_kabut.txt`, kepada siapa kredensial dikirim, akun mana yang menjadi prioritas, dan berapa bayarannya?

## C. Sulit (5 soal)
21. **[PhotoRec Carver → $CarvedFiles / Unallocated]** Ada satu gambar di ruang tak teralokasi yang tidak punya entri direktori. Temukan, sebutkan sektor awalnya (relatif terhadap awal disk), ukuran, dan MD5-nya. Apa isi percakapannya, dan informasi apa yang menghubungkan flashdisk ini dengan laptop korban?
22. **[Keyword Search pada unallocated / Hex]** Temukan fragmen teks "CATATAN BAYARAN" di unallocated. Wallet apa yang disebut dan dari pihak mana pembayaran berasal? Di sektor berapa fragmen itu berada?
23. **[Timeline]** Susun kronologi minimal 6 peristiwa dari 18 Maret sampai 9 April 2025 berdasarkan artefak di flashdisk ini (waktu WIB, artefak, dan path).
24. **[Analisis]** Flashdisk ini diduga pernah dicolokkan ke laptop korban (EVD-02). Nilai mana dari image ini yang dapat dicocokkan dengan artefak `.lnk` atau registry di laptop korban, dan nilai mana yang **tidak** dapat dibuktikan dari image ini saja?
25. **[Analisis atribusi]** Kumpulkan minimal empat artefak yang mengaitkan isi flashdisk dengan Rendi Saputra/r3ndyx, lalu nilai kekuatan masing-masing.

## D. Kesimpulan untuk Jaksa
Tulis kesimpulan singkat (maksimal 1 halaman) untuk Jaksa Penuntut Umum:
- **Apa yang terbukti** dari EVD-01 (sebut artefak dan path).
- **Apa yang tidak terbukti** atau belum dapat disimpulkan.
- **Keterbatasan** pemeriksaan (misalnya FAT tanpa waktu penghapusan, serial USB tidak tersimpan di image, data carving tanpa metadata).
