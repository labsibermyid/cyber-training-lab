# EVD-05 — Soal Latihan (Laptop Insider)

Persiapan: `EVD-05.dd`, time zone Asia/Jakarta. Ingest: **Recent Activity, Encryption Detection, Embedded File Extractor, Email Parser, Keyword Search, Hash Lookup, File Type Identification, Interesting Files** (buat aturan Interesting Files untuk path `*/Dropbox/*`).

## A. Dasar (10 soal)
1. **[mmls / OS info]** Sebutkan tabel partisi, sektor awal NTFS, nama komputer, dan pemilik terdaftar.
2. **[OS Accounts]** Apa SID akun Bagus?
3. **[USB Device Attached]** Perangkat USB apa saja yang pernah terhubung? Sebutkan merek, model, serial, dan waktunya.
4. **[Directory tree]** Di mana file `SLN_arsip_0502.7z` berada? Sebutkan semua salinannya (aktif maupun terhapus).
5. **[Embedded File Extractor / Encryption Detection → Analysis Results]** File apa yang ditandai "Encryption Detected", dan apa alasannya?
6. **[Email]** Siapa yang menawarkan pekerjaan kepada Bagus, untuk posisi apa, dan berapa gajinya?
7. **[Metadata]** Kapan `Surat_Pengunduran_Diri_Bagus.docx` dibuat dan diubah terakhir (metadata internal)? Berapa revisinya?
8. **[Recycle Bin]** File apa yang ada di Recycle Bin, apa path aslinya, dan kapan dihapus?
9. **[Web History]** Apa saja yang dicari Bagus di Google pada 25 April dan 3 Mei 2025?
10. **[Web Downloads]** Program apa yang diunduh Bagus sebelum mengemas data?

## B. Menengah (10 soal)
11. **[Deleted Files]** Folder apa yang dihapus di `Documents`? Sebutkan isi lengkapnya (6 file) dan strukturnya.
12. **[Keyword Search regex]** Buat regex NIK (16 digit diawali 33) dan regex nomor HP Indonesia. Berapa baris data pelanggan di file CSV yang terhapus? Sebutkan satu contoh NIK.
13. **[Recent Documents / .lnk]** `.lnk` mana yang menunjuk ke drive Z:? Apa *DriveType*-nya, dan file apa yang dibuka dari sana beserta tanggalnya?
14. **[.lnk + USB]** Buktikan bahwa arsip disalin ke flashdisk. Sebutkan VSN, label, dan waktu dari `.lnk`, lalu cocokkan dengan registry USB.
15. **[Dropbox artefak]** Dari `info.json` dan `sync_history.db`, sebutkan path folder Dropbox, kapan arsip diunggah, dengan siapa folder dibagikan, dan kapan arsip dilihat dari jarak jauh.
16. **[Hash / Duplicate]** Buktikan bahwa ketiga salinan arsip (Documents, Dropbox terhapus, `.dropbox.cache`) identik.
17. **[Text / Recycle Bin]** Apa kata sandi arsip, dan dari mana Anda memperolehnya? Buka arsip dan sebutkan isinya.
18. **[Email]** Apa arti kalimat "bekal dari tempat lama" dan "Bekal sedang saya siapkan, target awal Mei"? Sebutkan email pendukungnya beserta waktunya.
19. **[Registry NTUSER: TypedPaths / WordWheelQuery]** Apa yang diketik Bagus di address bar Explorer dan di kotak pencarian Explorer?
20. **[Prefetch / UserAssist]** Kapan 7-Zip dan Dropbox terakhir dijalankan?

## C. Sulit (5 soal)
21. **[Timeline]** Rekonstruksi 2 Mei 2025 pukul 17:55–18:51 menit demi menit (minimal 8 kejadian), dari pengumpulan sampai penghapusan staging.
22. **[Analisis anti-forensik]** Sebutkan semua upaya menghilangkan jejak beserta efektivitasnya: apa yang berhasil dihapus dan apa yang tetap tertinggal.
23. **[Korelasi EVD-11]** Arsip dengan MD5 sama ditemukan di file server EVD-11. Apa artinya, dan apa yang **tidak** dapat disimpulkan dari kesamaan hash itu?
24. **[Korelasi EVD-06/10]** Kaitkan isi arsip dan penerima (Pak H / Hartono, cahayaaset.co.id) dengan barang bukti EVD-06 dan EVD-10.
25. **[Analisis]** Bagus berdalih "folder itu untuk bahan presentasi IT". Uji dalih itu dengan minimal empat artefak.

## D. Kesimpulan untuk Jaksa
Tulis kesimpulan singkat: data apa yang terbukti dikumpulkan, dikemas, dan dikirim (Dropbox dan USB), kepada siapa ada indikasi pengiriman, motif yang terdokumentasi, apa yang tidak terbukti (misalnya isi flashdisk Kingston yang tidak disita, pengiriman password lewat WA), dan keterbatasannya (artefak Dropbox tiruan, metadata yang dapat diubah).
