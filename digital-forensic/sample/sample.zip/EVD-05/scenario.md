# EVD-05 — Laptop Insider (Exfiltration)

**Perkara:** Operasi KABUT GELAP — LP/B/117/IV/2025/SIBER/PDNR (fiktif)
**Barang bukti:** laptop dinas **SLN-LT-IT02**, pengguna **Bagus Prakoso** (staf IT PT Samudra Logistik Nusantara). Diamankan HRD dan diserahkan ke penyidik pada 20 Mei 2025 pukul 09.00 WIB, setelah Bagus mengajukan pengunduran diri.
**Image:** `EVD-05.dd` (raw, 88 MiB, MBR + NTFS). Zona waktu WIB.

## Latar belakang
Setelah serangan ransomware pada SLN-FS01 (17 Mei 2025, EVD-11), data pelanggan SLN dijual di forum (EVD-06). Audit akses menunjukkan Bagus beberapa kali membuka share `\\SLN-FS01\RAHASIA` pada akhir April, padahal folder itu di luar tugasnya. Pada 5 Mei ia menyusun surat pengunduran diri. Dalam wawancara ia membantah pernah menyalin data perusahaan.

## Yang diminta penyidik
1. Dokumen rahasia apa yang dikumpulkan, dari mana, dan kapan?
2. Bagaimana data dikemas dan apa kata sandinya?
3. Ke mana data dikirim (cloud, USB)?
4. Adakah motif atau pihak penerima?
5. Apa upaya menghilangkan jejak?
