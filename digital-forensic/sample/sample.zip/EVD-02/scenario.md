# EVD-02 — Laptop Korban BEC

**Perkara:** Operasi KABUT GELAP — LP/B/117/IV/2025/SIBER/PDNR (fiktif)
**Barang bukti:** laptop dinas **SLN-LT-FIN07** milik PT Samudra Logistik Nusantara, pengguna **Dewi Anggraini** (staf keuangan). Diserahkan pelapor (SLN) pada 17 April 2025 pukul 17.30 WIB dalam keadaan mati.
**Image:** `EVD-02.dd` (raw, 90 MiB, GPT: EFI FAT16 + NTFS "OS"). Zona waktu WIB.

## Latar belakang
Pada 15 April 2025 SLN mentransfer **Rp 1.475.000.000** untuk invoice INV/BPS/2025/0412 ke rekening **Bank Arta Niaga 7310448201 a.n. CV Baja Prima Sentosa**. Vendor asli, PT Baja Prima Sentosa (`bajaprimasentosa.co.id`), menyatakan tidak pernah mengganti rekening. Dewi mengaku menerima email "perubahan rekening" yang tampak berasal dari vendor dan membuka lampirannya.

Dewi juga mengaku:
- pada 7 April ada "kurir BPS" yang memintanya mencetak invoice dari flashdisk milik kurir di laptopnya;
- pada 8 April ia pernah memasukkan kata sandi di tautan "reset password".

Persetujuan pembayaran tercatat atas nama manajer **Hendra Wibisono**, padahal ia sedang cuti (lihat EVD-09).

## Yang diminta penyidik
1. Rekonstruksi alur email BEC: pengirim, domain tiruan, IP asal, dan lampiran.
2. Buktikan Dewi mengunjungi halaman phishing dan apa yang terjadi setelahnya.
3. Pulihkan file yang dihapus Dewi (Recycle Bin) dan file yang dihapus permanen.
4. Identifikasi flashdisk "kurir" dari jejak USB dan `.lnk`, lalu cocokkan dengan EVD-01.
