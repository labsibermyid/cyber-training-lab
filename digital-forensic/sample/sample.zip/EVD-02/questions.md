# EVD-02 — Soal Latihan (Laptop Korban BEC)

Persiapan: *Add Data Source → Disk Image* `EVD-02.dd`, time zone **Asia/Jakarta**. Ingest: **Recent Activity, Email Parser, Embedded File Extractor, File Type Identification, Extension Mismatch, Keyword Search, Hash Lookup, Interesting Files**.

## A. Dasar (10 soal)
1. **[Data Sources / mmls]** Jenis tabel partisi apa yang dipakai? Sebutkan setiap partisi beserta sektor awal, nama partisi, dan file system-nya.
2. **[Data Source Summary / Operating System]** Apa nama komputer, versi OS, dan *RegisteredOwner* laptop ini?
3. **[OS Accounts / Users folder]** Akun pengguna apa saja yang ada? Sebutkan SID akun Dewi.
4. **[Directory tree]** Berapa file `.eml` di folder Email milik Dewi?
5. **[Communications / Email Messages]** Siapa pengirim (From), Reply-To, dan waktu email "RE: Invoice INV/BPS/2025/0412 - Perubahan Rekening"?
6. **[Email Messages → Attachments]** Apa saja nama lampiran email tersebut?
7. **[Recycle Bin]** Ada berapa item di Recycle Bin milik Dewi? Sebutkan path asli dan waktu penghapusan masing-masing.
8. **[USB Device Attached]** Perangkat USB apa saja yang pernah terhubung (vendor, produk, serial)?
9. **[Web History]** Pada 8 April 2025, URL apa yang dikunjungi Dewi tepat setelah menerima email reset password?
10. **[Web Downloads]** Sebutkan file yang diunduh dari OWA pada 14 April 2025 beserta path tujuannya.

## B. Menengah (10 soal)
11. **[Email header / Keyword Search]** Dari header `Received`, IP mana yang mengirim email BEC? Apa perbedaan domain pengirim dengan domain vendor asli?
12. **[Keyword Search: "7310448201"]** File mana saja yang memuat nomor rekening penampung? Sebutkan minimal tiga lokasi berbeda.
13. **[File Metadata / Application]** Siapa *Author* PDF `Surat_Perubahan_Rekening.pdf`? Nama itu pernah muncul di barang bukti lain yang mana?
14. **[Embedded File Extractor / Analisis docm]** Buka `$RK7Q2MX.docm` (Recycle Bin). Apa isi `word/vbaProject.bin`, dan URL/IP apa yang disebut di dalamnya? Apakah file ini berbahaya?
15. **[Hash / File Search by MD5]** Apakah lampiran `.docm` hasil ekstraksi email identik dengan `$RK7Q2MX.docm` di Recycle Bin? Buktikan dengan MD5.
16. **[ADS / Zone.Identifier]** Buka ADS `Zone.Identifier` milik file di Recycle Bin dan di folder Downloads. Apa ZoneId, ReferrerUrl, dan HostUrl-nya? Apa artinya?
17. **[Recent Documents / .lnk]** `.lnk` mana yang menunjuk ke drive E:? Apa *DriveType*, *Volume Serial*, dan *Volume Label* yang tercatat? Kapan file target dibuka?
18. **[Registry: SOFTWARE → EMDMgmt]** Temukan key EMDMgmt untuk flashdisk SanDisk. Bilangan desimal apa yang mengikuti label, dan apa hubungannya dengan nilai di soal 17?
19. **[Web History]** Domain tiruan apa yang dikunjungi pada 14 April pukul 09.05, dan apa yang dicari Dewi di Google sebelumnya?
20. **[Email]** Siapa yang menyetujui pembayaran, kapan, dan dari terminal mana menurut email e-Approval? Mengapa ini janggal?

## C. Sulit (5 soal)
21. **[Keyword Search di Unallocated]** Ada catatan kronologi yang dihapus permanen (tidak lewat Recycle Bin). Temukan teksnya. Di sektor disk berapa catatan itu berada, dan informasi baru apa yang ada di dalamnya?
22. **[Korelasi EVD-01]** Buktikan bahwa flashdisk yang dicolokkan pada 7 April 2025 adalah EVD-01. Gunakan minimal tiga nilai yang cocok, termasuk ukuran file target `.lnk`.
23. **[Timeline]** Buat kronologi 7–17 April 2025 (minimal 10 kejadian) dengan sumber artefak masing-masing.
24. **[Analisis]** File `Bukti_Transfer_BPS_0415.pdf`: dari URL mana file itu diunduh, ke mana dipindahkan, kapan dihapus, dan apa isinya?
25. **[Analisis]** Apakah ada bukti bahwa makro di `.docm` *dieksekusi*? Artefak apa yang mendukung bahwa dokumen dibuka, dan artefak apa yang tidak ada?

## D. Kesimpulan untuk Jaksa
Tulis kesimpulan singkat: apa yang terbukti tentang cara Dewi tertipu, apa yang **tidak** terbukti (misalnya keterlibatan Dewi, eksekusi makro, siapa penyetuju), dan keterbatasannya (artefak registry hasil rekonstruksi, waktu Recycle Bin dari `$I`, dll).
