# EVD-04 — Disk Webserver yang Di-deface

**Perkara:** Operasi KABUT GELAP (fiktif). Laporan Koperasi Simpan Pinjam Makmur Bersama, Kudus.
**Barang bukti:** image logical volume root webserver **ksp-web01** (Ubuntu 22.04, Apache + PHP) yang melayani `www.kspmakmur.id` (203.0.113.45). Diakuisisi penyedia hosting atas permintaan penyidik pada 20 Juni 2025 pukul 08.49 WIB.
**Image:** `EVD-04.dd` (raw, 64 MiB, **ext4 tanpa tabel partisi**, seperti image LV). Zona waktu WIB.

## Latar belakang
Pada pagi 20 Juni 2025 anggota koperasi melapor bahwa beranda situs berganti tulisan "HACKED BY Gh0st_K4but". Admin, Agus Salim, login pukul 08.12 lewat SSH, sempat melihat-lihat folder upload, dan menyalin halaman deface ke `/root` sebelum server dimatikan. Situs memakai CMS lokal "ksp-cms 1.4" yang punya celah unggah file.

## Yang diminta penyidik
1. Bagaimana penyerang masuk, dan file apa yang diunggah?
2. Temukan semua webshell, termasuk yang disembunyikan.
3. Buktikan waktu unggah dengan artefak file system, lalu konfirmasi dengan cuplikan log.
4. Apakah ada persistensi (backdoor) setelah deface?
5. Hubungkan pelaku dengan kelompok KABUTGELAP dan barang bukti lain.
