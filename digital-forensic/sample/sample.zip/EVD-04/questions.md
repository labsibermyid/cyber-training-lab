# EVD-04 — Soal Latihan (Webserver Di-deface)

Persiapan: `EVD-04.dd` (*Add Data Source → Disk Image*, Autopsy mendeteksi ext4 langsung tanpa volume system). Time zone Asia/Jakarta. Ingest: **File Type Identification, Extension Mismatch Detector (centang "check all file types"), Hash Lookup, Keyword Search, EXIF Parser, Interesting Files, PhotoRec Carver**.

## A. Dasar (10 soal)
1. **[Data Sources / fsstat]** Apa file system image ini? Apakah ada tabel partisi? Sebutkan volume name dan kapan terakhir di-mount.
2. **[/etc]** Apa hostname server, versi OS, dan zona waktunya?
3. **[/etc/passwd]** Akun pengguna interaktif apa saja yang ada? Apa UID `www-data`?
4. **[Apache config]** Di mana DocumentRoot situs, dan apakah `.htaccess` diizinkan (AllowOverride)?
5. **[Directory tree]** Apa isi `index.html` di DocumentRoot sekarang? Sebutkan handle pelaku dan nama-nama yang disapa di "greetz".
6. **[Directory tree]** Berapa file di `uploads/2025/06/`, termasuk file tersembunyi (diawali titik)?
7. **[Text]** Apa isi `uploads/2025/06/.htaccess`, dan apa akibatnya terhadap file `.jpg` di folder itu?
8. **[EXIF]** Kamera apa yang dipakai untuk foto berita di `uploads/2025/05/`, dan di mana koordinat GPS-nya?
9. **[Text]** Menurut `/home/agus/catatan_server.txt`, apa yang sudah diketahui admin tentang CMS-nya?
10. **[Deleted Files]** Sebutkan file berstatus terhapus pada volume ini.

## B. Menengah (10 soal)
11. **[Extension Mismatch]** File mana yang ekstensinya .jpg tetapi isinya bukan gambar? Apa tipe sebenarnya, dan apa kunci akses `?k=` yang tertulis di dalamnya?
12. **[Keyword Search: "Gh0st_K4but"]** Di file mana saja handle ini muncul? Temukan webshell kedua.
13. **[File Metadata ext4]** Bandingkan Created (crtime), Modified (mtime), Changed (ctime), dan Accessed `uploads/2025/06/.cache.php`. Apa yang janggal, dan apa kesimpulan Anda?
14. **[Metadata / Owner]** Siapa pemilik (UID/GID) `avatar_8812.jpg` dan `.cache.php`? Apa artinya bagi cara file itu masuk?
15. **[Text]** Apa isi `/home/agus/.ssh/authorized_keys`? Kunci mana yang mencurigakan, dan kapan file itu terakhir diubah?
16. **[Hash / Duplicate]** File mana yang MD5-nya sama dengan `index.html` deface? Siapa yang membuatnya, dan kapan (lihat `.bash_history`)?
17. **[Keyword Search regex IP]** Dari access log, IP mana yang melakukan login admin, upload, dan memanggil webshell? Apakah IP itu muncul di barang bukti lain?
18. **[Timeline]** Konfirmasi waktu unggah webshell dari dua sumber berbeda: metadata file system dan log. Apakah keduanya cocok?
19. **[Hash Lookup]** File mana yang tertandai *Notable*?
20. **[Analisis kode]** Jelaskan celah di `admin/upload.php` yang dimanfaatkan penyerang.

## C. Sulit (5 soal)
21. **[Deleted ext4 + Keyword Search Unallocated]** `index.php` asli terhapus. Apa yang ditampilkan Autopsy untuk file tersebut (ukuran/isi)? Pulihkan isinya lewat Keyword Search pada unallocated, lalu sebutkan kalimat sambutan aslinya.
22. **[Unallocated]** Ada skrip yang diunduh penyerang ke `/tmp/.x/` lalu dihapus. Temukan nama dan URL asalnya dari unallocated.
23. **[Rekonstruksi]** Susun rangkaian serangan 20 Juni 01:58–02:33 (minimal 10 langkah) dengan bukti file system sebagai sumber utama dan log sebagai konfirmasi.
24. **[Korelasi]** Kaitkan EVD-04 dengan kelompok KABUTGELAP dan EVD lain: email/Tox, IP, nama alias, dan pola infrastruktur.
25. **[Analisis]** Agus login dan menjalankan perintah sebelum image dibuat. Artefak mana yang mungkin terkontaminasi oleh tindakannya, dan bagaimana membedakannya dari aktivitas penyerang?

## D. Kesimpulan untuk Jaksa
Tulis kesimpulan singkat: cara masuk, perubahan yang dilakukan, persistensi, identitas daring pelaku yang dapat dikaitkan, apa yang tidak terbukti (misalnya siapa orang di balik IP/handle), dan keterbatasannya (kontaminasi oleh admin, log yang hanya cuplikan, index.php asli tidak utuh secara metadata).
