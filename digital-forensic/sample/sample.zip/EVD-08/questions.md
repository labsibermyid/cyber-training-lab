# EVD-08 — Soal Latihan (Mesin Penyerang)

Persiapan: `EVD-08.dd`, time zone Asia/Jakarta. Ingest: **Encryption Detection, Hash Lookup (KABUT_known_bad), Keyword Search, File Type Identification, Extension Mismatch, Interesting Files, PhotoRec Carver**. Perhatikan bahwa Autopsy menampilkan setiap partisi sebagai `vol` terpisah.

## A. Dasar (10 soal)
1. **[mmls / Data Sources]** Sebutkan semua partisi: slot, sektor awal, panjang, dan tipe. Partisi mana yang tidak berisi file system?
2. **[fsstat]** Apa label volume partisi ketiga? Mengapa partisi ini disebut "tersembunyi"?
3. **[/etc]** Apa hostname, distribusi, dan akun pengguna di sistem?
4. **[/etc/fstab]** Partisi apa yang di-mount otomatis dan mana yang sengaja tidak?
5. **[Directory tree]** Sebutkan isi folder `tools/` dan `tools/build/`.
6. **[Text]** Apa isi `recon/nmap_sln_20250512.txt`? Layanan apa yang ditemukan di IP VPN SLN?
7. **[Text]** Dari mana dan kapan kredensial di `recon/kredensial_valid.txt` diperoleh?
8. **[Text]** Apa isi `.ssh/id_ed25519.pub`? Di barang bukti mana kunci ini pernah muncul?
9. **[Hash Lookup]** File mana yang tertandai *Notable*?
10. **[Deleted Files]** File apa yang dihapus di partisi ext4? Apa yang ditampilkan Autopsy tentang ukurannya?

## B. Menengah (10 soal)
11. **[Text]** Menurut `vpn/conn.log`, akun apa yang dipakai untuk VPN ke SLN? Kapan sesi RDP ke 10.20.1.15 berlangsung (dua sesi)?
12. **[Text]** Baca `tools/deploy_notes.md`. Sebutkan langkah deploy ransomware ke SLN dan path tujuan locker di FS01.
13. **[Hash / Korelasi]** Bandingkan MD5 `tools/build/kbl_arunika.exe` dengan `kbl.exe` di EVD-03, dan MD5 `tools/build/kbl_sln.exe` dengan biner di EVD-11. Apa kesimpulan Anda?
14. **[Hash / Korelasi]** File `loot/KSP/ksp_cms_2025-06-19.sql` identik dengan file mana di EVD-04 dan EVD-06?
15. **[Shell history]** Baca `.zsh_history`. Ubah epoch menjadi WIB untuk minimal tiga perintah penting, dan jelaskan apa yang dilakukan setiap perintah.
16. **[Encryption Detection]** File mana yang ditandai *Encryption Suspected*? Mengapa file itu mencurigakan dilihat dari lokasi, nama, dan ukurannya?
17. **[File Metadata ext4]** Bandingkan crtime dan mtime file kontainer. Apa yang janggal?
18. **[Hidden partition]** Sebutkan isi partisi tersembunyi. Informasi apa yang ada di `kunci.txt` dan `wallet.txt`?
19. **[Keyword Search pada unallocated/swap]** Cari "SWAPSPACE2" dan "openssl". Apa yang ditemukan di partisi swap?
20. **[Text]** Menurut `bukti_bayar_SLN.txt`, apakah SLN membayar tebusan? Berapa, kapan, dan ke wallet mana?

## C. Sulit (5 soal)
21. **[Dekripsi kontainer]** Ekstrak `.t`, lalu dekripsi dengan informasi dari partisi tersembunyi atau swap. Tuliskan perintahnya dan sebutkan isi kontainer.
22. **[Analisis isi kontainer]** Bagaimana pembagian tebusan SLN? Siapa saja pihak yang disebut, dan ke wallet mana bagian masing-masing?
23. **[Keyword Search unallocated ext4]** Pulihkan isi `loot/SLN/kredensial_dump.txt` yang dihapus. Akun apa yang ada di dalamnya?
24. **[Rekonstruksi]** Susun kronologi aktivitas penyerang terhadap SLN (12 April s.d. 20 Mei 2025), Arunika, dan KSP dengan artefak masing-masing.
25. **[Analisis]** Fajar mengaku laptopnya "hanya untuk latihan CTF" (folder `ctf/`). Bantah atau dukung klaim itu dengan bukti. Apa saja keterbatasan atribusi "Fajar = f4j4r = operator KABUTGELAP"?

## D. Kesimpulan untuk Jaksa
Tulis kesimpulan singkat: peran mesin ini dalam serangan SLN, Arunika, dan KSP; bukti kepemilikan tebusan; apa yang tidak terbukti (misalnya siapa kabut_admin, apakah wallet benar menerima dana); dan keterbatasannya (log cuplikan, history dapat dihapus/diubah, sampel inert).
