# EVD-08 — Mesin Penyerang

**Perkara:** Operasi KABUT GELAP (fiktif)
**Barang bukti:** SSD laptop **kali** milik **Fajar Nugroho** (alias *f4j4r* / *kabut_admin*?), disita dari kamar kos di Semarang pada 16 Juli 2025 pukul 05.40 WIB.
**Image:** `EVD-08.dd` (raw, 80 MiB, MBR dengan 3 partisi). Zona waktu WIB.

## Latar belakang
IP 198.51.100.77 muncul sebagai pengirim email BEC (EVD-02), pengirim email ke Arunika (EVD-03), dan pengunggah webshell ke webserver KSP (EVD-04). Penyedia VPS memberikan data sewa yang mengarah ke Fajar. Saat penggeledahan, Fajar mengaku laptopnya "hanya untuk latihan CTF".

## Yang diminta penyidik
1. Petakan seluruh partisi, termasuk yang tidak di-mount oleh sistem.
2. Temukan alat serangan, hasil pemindaian, kredensial curian, dan biner ransomware.
3. Buka kontainer terenkripsi.
4. Hubungkan mesin ini dengan serangan SLN (EVD-11), Arunika (EVD-03), dan KSP (EVD-04).
5. Identifikasi upaya anti-forensik.
