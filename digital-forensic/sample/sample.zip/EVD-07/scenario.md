# EVD-07 — Backup Ponsel Pelaku Penipuan Online

**Perkara:** Operasi KABUT GELAP (fiktif). Klaster penipuan investasi "Cahaya X Trade".
**Barang bukti:** flashdisk OTG 64 GB berisi folder `Backup_Redmi_2025-07-10` (backup ADB ponsel Xiaomi Redmi Note 13 Pro), disita dari rumah **Andika Wijaya** pada 15 Juli 2025. Ponsel aslinya sudah di-*factory reset*.
**Image:** `EVD-07.dd` (raw, 72 MiB, **FAT32 tanpa tabel partisi**). Zona waktu WIB. Untuk FAT, atur time zone data source ke Asia/Jakarta.

## Latar belakang
Tiga korban melapor tertipu "platform trading Cahaya X Trade" setelah dihubungi CS bernama "Rina" lewat WhatsApp. Nomor CS terdaftar atas nama Andika Wijaya. Pada malam 14 Juli, sehari sebelum penggeledahan kantor PT Cahaya Aset Digital (EVD-10), Andika diminta "membersihkan HP".

## Yang diminta penyidik
1. Identifikasi korban, modus, nominal, dan rekening penampung.
2. Buktikan Andika memakai persona "Rina CS Cahaya".
3. Temukan hubungan dengan atasan ("Pak H"), joki rekening, dan alur ke wallet kripto.
4. Pulihkan data yang dihapus pada 14 Juli malam.
