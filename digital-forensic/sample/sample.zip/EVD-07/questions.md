# EVD-07 — Soal Latihan (Backup Ponsel Penipuan Online)

Persiapan: `EVD-07.dd`, time zone Asia/Jakarta. Ingest: **Android Analyzer, EXIF Parser, Keyword Search (tambahkan regex rekening/HP), File Type Identification, Hash Lookup, PhotoRec Carver, Interesting Files**.

## A. Dasar (10 soal)
1. **[Data Sources / fsstat]** Apa file system image ini, apa label volumenya, dan apakah ada tabel partisi?
2. **[Text]** Menurut `backup_info.txt`, perangkat apa yang di-backup, kapan, dan dengan cara apa?
3. **[Directory tree]** Berapa file ekspor chat WhatsApp yang masih aktif? Sebutkan lawan bicaranya.
4. **[Text]** Nama tampilan apa yang dipakai pemilik ponsel di chat dengan korban?
5. **[Images]** Berapa screenshot bukti transfer dari korban yang masih aktif? Sebutkan nominal dan rekening tujuan masing-masing.
6. **[Text]** Sebutkan tahapan modus dalam `naskah_cs_v3.txt`.
7. **[Spreadsheet]** Sebutkan rekening di `rekening_aktif.xlsx` beserta statusnya.
8. **[Communications / Messages (Android Analyzer)]** Sebutkan SMS notifikasi bank yang mencatat dana masuk.
9. **[Contacts / Call Logs]** Siapa saja kontak yang tersimpan? Kapan panggilan terakhir dengan "Pak H"?
10. **[Deleted Files]** Sebutkan file yang dihapus beserta jenisnya.

## B. Menengah (10 soal)
11. **[Deleted Files + Text]** Pulihkan chat dengan Mbak Lusiana. Berapa uang yang ditransfer, ke rekening mana, dan kapan?
12. **[Deleted Files]** Pulihkan `rekening_lama.txt`. Informasi apa yang menghubungkan ponsel ini dengan kasus BEC di SLN (EVD-02)?
13. **[Keyword Search: "7310448201"]** Di file mana saja rekening ini muncul? Apa peran rekening itu di dua kejahatan yang berbeda?
14. **[Metadata audio]** Baca metadata/komentar voice note. Apa isi transkripnya, dan voice note mana yang dihapus?
15. **[EXIF/Geolocation]** Foto `IMG_20250603_104455.jpg` dan `IMG_20250610_090212.jpg` diambil di mana dan kapan? Apa kaitannya dengan chat?
16. **[Chat]** Menurut chat dengan "Pak H", ke wallet mana hasil penipuan dikirim, dan instruksi apa yang diberikan pada 21 Juni dan 14 Juli?
17. **[Chat]** Siapa Dimas Aryo, dan apa perannya? Sebutkan fee dan batas transaksinya.
18. **[Text]** Dari `catatan_setoran.txt`, berapa total USDT yang disetor ke pool?
19. **[Call Logs]** Ada kontak bernama "Fajar Kabut". Kapan panggilan dengannya terjadi? Mengapa ini relevan dengan EVD-04/EVD-08?
20. **[Timeline]** Urutkan peristiwa korban Ibu Ratna Sari dari bujukan pertama sampai permintaan "pajak penarikan".

## C. Sulit (5 soal)
21. **[PhotoRec Carver]** Ada foto di unallocated yang entri direktorinya sudah hilang. Temukan foto itu, sebutkan sektor dan MD5-nya, lalu jelaskan isinya. Kaitkan dengan foto lain yang diambil pada waktu berdekatan.
22. **[Analisis]** Hitung total kerugian tiga korban berdasarkan artefak (chat, screenshot, SMS). Adakah pembayaran yang hanya terbukti dari satu sumber?
23. **[Analisis atribusi]** Buktikan bahwa "Rina CS Cahaya" adalah pemilik ponsel ini, yaitu Andika. Gunakan minimal empat artefak.
24. **[Analisis anti-forensik]** Apa saja yang dihapus pada 14 Juli malam, apa yang berhasil dipulihkan, dan apa yang tidak? Mengapa FAT tidak menyimpan waktu penghapusan, dan bagaimana Anda memperkirakannya?
25. **[Korelasi]** Petakan hubungan EVD-07 dengan EVD-02 (rekening BEC), EVD-06/EVD-10 (wallet pool), dan EVD-10 (alamat kantor dari GPS).

## D. Kesimpulan untuk Jaksa
Tulis kesimpulan singkat: korban, nominal, rekening, peran Andika dan pihak lain, apa yang tidak terbukti (misalnya identitas "Pak H" hanya dari nama kontak dan nomor, transfer ke wallet pool hanya dari catatan pribadi), dan keterbatasannya (backup bukan ponsel asli, voice note tiruan berupa transkrip metadata, FAT tanpa waktu penghapusan).
