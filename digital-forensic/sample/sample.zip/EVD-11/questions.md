# EVD-11 — UJIAN AKHIR (File Server SLN-FS01)

**Ketentuan:** soal tidak menyebut modul atau teknik. Setiap jawaban wajib mencantumkan path lengkap, nilai yang ditemukan (waktu WIB, MD5, inode/offset bila relevan), dan cara Anda membuktikannya. Untuk soal korelasi, sebutkan image lain dan artefak pasangannya.

Disarankan: satu case Autopsy berisi EVD-01, EVD-02, EVD-05, EVD-08, EVD-10, dan EVD-11 sebagai data source terpisah.

## A. Orientasi (6 soal)
1. Deskripsikan struktur disk: partisi, tipe, dan sektor awal. Partisi mana yang tidak memiliki file system?
2. Identifikasi sistem: nama host, OS, dan akun pengguna beserta SID-nya.
3. Akun mana yang profilnya paling baru dibuat, dan kapan? Mengapa ini janggal?
4. Berapa file terenkripsi, di share mana saja, dan berapa catatan tebusan?
5. Sebutkan ID korban, wallet, nominal, dan kontak dalam catatan tebusan.
6. Kapan proses enkripsi dimulai dan berakhir?

## B. Analisis (10 soal)
7. Temukan biner yang menjalankan enkripsi. Di mana letaknya, dan apa yang janggal dari stempel waktunya? Buktikan.
8. Bagaimana penyerang masuk ke FS01? Sebutkan akun, sumber koneksi, protokol, dan waktu dua sesi.
9. Dari mana biner dan catatan tebusan dibawa masuk ke server? Tunjukkan artefak yang menunjuk ke sumber di luar server.
10. Temukan bukti penghapusan atau pelemahan mekanisme pemulihan.
11. Apakah ada data yang dibawa keluar oleh penyerang dari FS01? Sebutkan file, waktu, tujuan, dan apa yang dapat diketahui tanpa kata sandi.
12. Ada folder yang sengaja ditinggalkan pelaku sebagai "bukti". Apa isinya, dan dari mana asal file tersebut?
13. Akun VPN siapa yang dipakai, dan dari IP mana? Apakah pemilik akun kemungkinan pelakunya? Jelaskan.
14. Mengapa akun `svc_backup` bisa dipakai? Kumpulkan semua artefak tentang kelemahan akun ini, termasuk yang berasal dari waktu jauh sebelum serangan.
15. Apakah tebusan dibayar? Sebutkan buktinya.
16. Identifikasi **tiga** artefak yang tampak terkait serangan tetapi sebenarnya tidak. Jelaskan mengapa masing-masing harus dikesampingkan.

## C. Korelasi lintas barang bukti (6 soal)
17. Hubungkan akun VPN pada soal 13 dengan EVD-01 dan EVD-02: kapan dan bagaimana kredensialnya dicuri?
18. Hubungkan IP sumber VPN dengan barang bukti lain (minimal tiga).
19. Buktikan bahwa biner locker dan catatan tebusan berasal dari mesin di EVD-08. Gunakan nilai yang dapat diverifikasi.
20. Buktikan hubungan folder "bukti" (soal 12) dengan EVD-05. Siapa yang membuat arsip itu, kapan, dan bagaimana arsip itu bisa sampai ke tangan penyerang?
21. Ikuti uang tebusan: ke mana nilai 4.2 BTC dibagi, dan bagaimana sebagian dicuci? (EVD-08, EVD-10)
22. Siapa saja pelaku dan perannya dalam rantai ini? Sertakan untuk masing-masing satu artefak terkuat dari image yang berbeda.

## D. Rekonstruksi & kesimpulan (3 soal)
23. Susun **timeline terpadu** 18 Maret – 21 Mei 2025 (minimal 15 kejadian dari minimal 5 image), dengan sumber artefak tiap kejadian.
24. Tetapkan apakah "satu rantai insiden" terbukti. Untuk setiap mata rantai (phishing, kredensial, exfiltration, ransomware), nyatakan bukti utama, bukti penguat, dan tingkat keyakinan.
25. **Kesimpulan untuk Jaksa (maks. 1 halaman):** apa yang terbukti, apa yang tidak terbukti (termasuk identitas *kabut_admin*), keterbatasan pemeriksaan, dan bukti tambahan yang direkomendasikan untuk dimintakan (provider, bank/exchange, log server, dan sebagainya).
