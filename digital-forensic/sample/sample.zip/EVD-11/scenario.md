# EVD-11 — UJIAN AKHIR: File Server SLN-FS01

**Perkara:** Operasi KABUT GELAP — LP/B/117/IV/2025/SIBER/PDNR (fiktif)
**Barang bukti:** disk sistem file server **SLN-FS01** (Windows Server 2019, 10.20.1.15) PT Samudra Logistik Nusantara. Diakuisisi pada 22 Mei 2025.
**Image:** `EVD-11.dd` (raw, 92 MiB, GPT). Zona waktu WIB.

## Situasi
Pada pagi 17 Mei 2025 seluruh share di FS01 tidak dapat dibuka dan muncul catatan tebusan. Direksi kemudian memutuskan membayar tebusan. Manajemen bertanya kepada penyidik:

> "Apakah serangan ini berdiri sendiri, atau bagian dari rangkaian kejadian sejak April (email phishing, penipuan pembayaran vendor, karyawan yang resign)? Siapa saja yang terlibat, dan bagaimana caranya?"

## Tugas
Buktikan (atau bantah) bahwa terjadi **satu rantai insiden: phishing → pencurian kredensial → exfiltration → ransomware**. Gunakan EVD-11 sebagai titik awal dan korelasikan dengan **EVD-01, EVD-02, EVD-05, EVD-08, dan EVD-10**.

Image ini sengaja berisik. Ada artefak yang tampak mencurigakan tetapi tidak berkaitan. Anda bebas memilih modul dan teknik Autopsy yang dianggap perlu.
